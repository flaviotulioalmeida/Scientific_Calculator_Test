import calculadora from "./calculadora";

describe("Testes para a calculadora científica", () => {

    test("Teste para a função de raiz quadrada", () => {
        expect(calculadora.sqrt(9)).toBe(3);
    });

    test("Teste para a função de logaritmo natural", () => {
        expect(calculadora.log(10)).toBe(2.302585092994046);
    });

    test("Teste para a função de logaritmo base 10", () => {
        expect(calculadora.log10(100)).toBe(2);
    });

    test("Teste para a função de seno", () => {
        expect(calculadora.sin(Math.PI / 2)).toBe(1);
    });

    test("Teste para a função de cosseno", () => {
        expect(calculadora.cos(Math.PI / 2)).toBe(6.123233995736766e-17);
    });

    test("Teste para a função de tangente", () => {
        expect(calculadora.tan(Math.PI / 4)).toBe(0.9999999999999999);
    });

    test("Teste para a função de seno hiperbólico", () => {
        expect(calculadora.sinh(0)).toBe(0);
    });

    test("Teste para a função de arco seno", () => {
        expect(calculadora.asin(1)).toBe(Math.PI / 2);
    });

    test("Teste para a função de arco cosseno", () => {
        expect(calculadora.acos(0)).toBe(Math.PI / 2);
    });

    test("Teste para a função de arco tangente", () => {
        expect(calculadora.atan(1)).toBe(Math.PI / 4);
    });

    test("Teste para a função de exponencial", () => {
        expect(calculadora.exp(1)).toBe(Math.E);
    });

    test("Teste para a função de potência", () => {
        expect(calculadora.power(2, 3)).toBe(8);
    });

    test("Teste para a função de tangente hiperbólica", () => {
        expect(calculadora.tanh(0)).toBe(0);
    });

    test("Teste para a função de raiz cúbica", () => {
        expect(calculadora.cbrt(8)).toBe(2);
    });

    test("Teste para a função de raiz quadrada", () => {
        expect(calculadora.sqrt(9)).toBe(3);
    });

    test("Teste para função de subtração", () => {
        expect(calculadora.subtract(10, 5)).toBe(5);
    });

    test("Teste para função de adição", () => {
        expect(calculadora.add(10, 5)).toBe(15);
    });

    test("Teste para função de multiplicação", () => {
        expect(calculadora.multiply(10, 5)).toBe(50);
    });

    test("Teste para função de divisão", () => {
        expect(calculadora.divide(10, 5)).toBe(2);
    });

    test("Teste para função de resto", () => {
        expect(calculadora.modulo(10, 5)).toBe(0);
    });

})

